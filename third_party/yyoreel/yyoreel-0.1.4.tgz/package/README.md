# yyoreel

CLI that records scripted browser videos as MP4, GIF, or WebM files from JSON configs.

Define steps (clicks, key presses, drags, pauses) and yyoreel drives a headless Chrome instance, streams lossless PNG frames from Chrome on a fixed output clock, adds cursor animation, keystroke overlays, and sound effects, and encodes the result with ffmpeg.

## Installation

```bash
npm install yyoreel
```

## Quick Start

```bash
npx yyoreel init --name my-video --url https://example.com
npx yyoreel record
```

## Examples

<!-- EXAMPLES:START -->

**[custom-theme](../../examples/custom-theme)** - Demonstrates fully customizing the cursor overlay and keystroke HUD appearance using a code editor page.

<video src="../../examples/custom-theme/videos/custom-theme.mp4" controls muted width="100%"></video>

**[drag-and-drop](../../examples/drag-and-drop)** - Demonstrates dragging elements between positions on a kanban board.

<video src="../../examples/drag-and-drop/videos/drag-and-drop.mp4" controls muted width="100%"></video>

**[form-filling](../../examples/form-filling)** - Demonstrates typing into form fields and clicking a submit button, simulating a login flow.

<video src="../../examples/form-filling/videos/form-filling.mp4" controls muted width="100%"></video>

**[gif-output](../../examples/gif-output)** - Demonstrates outputting the recording as an animated GIF instead of the default MP4.

<video src="../../examples/gif-output/videos/gif-output.gif" controls muted width="100%"></video>

**[hello-world](../../examples/hello-world)** - The simplest possible yyoreel example. Opens a landing page and clicks the call-to-action button.

<video src="../../examples/hello-world/videos/hello-world.mp4" controls muted width="100%"></video>

**[keyboard-shortcuts](../../examples/keyboard-shortcuts)** - Demonstrates pressing key combos and displaying them in the keystroke HUD overlay. Uses a code editor page as the target.

<video src="../../examples/keyboard-shortcuts/videos/keyboard-shortcuts.mp4" controls muted width="100%"></video>

**[mobile-viewport](../../examples/mobile-viewport)** - Demonstrates recording at mobile device dimensions using a finance app interface.

<video src="../../examples/mobile-viewport/videos/mobile-viewport.mp4" controls muted width="100%"></video>

**[modifier-clicks](../../examples/modifier-clicks)** - Demonstrates clicking elements with modifier keys held down, simulating multi-select in a file manager.

<video src="../../examples/modifier-clicks/videos/modifier-clicks.mp4" controls muted width="100%"></video>

**[multi-demo](../../examples/multi-demo)** - Demonstrates defining multiple videos in a single config file, each producing its own output from the same page.

<video src="../../examples/multi-demo/videos/homepage.mp4" controls muted width="100%"></video>

**[page-scrolling](../../examples/page-scrolling)** - Demonstrates scrolling the page and scrolling within a specific container element on a blog post layout.

<video src="../../examples/page-scrolling/videos/page-scrolling.mp4" controls muted width="100%"></video>

**[screenshots](../../examples/screenshots)** - Demonstrates capturing PNG screenshots at specific points during a recording. Useful for generating static marketing assets or documentation images alongside videos.

<video src="../../examples/screenshots/videos/screenshots.mp4" controls muted width="100%"></video>

**[shared-steps](../../examples/shared-steps)** - Demonstrates using `include` to share common setup steps across videos. The shared steps dismiss a cookie consent banner before the main video steps run.

<video src="../../examples/shared-steps/shared-steps.mp4" controls muted width="100%"></video>

**[webm-output](../../examples/webm-output)** - Demonstrates outputting the recording as a WebM video using VP9 encoding.

<video src="../../examples/webm-output/webm-output.webm" controls muted width="100%"></video>

<!-- EXAMPLES:END -->

## Commands

### `yyoreel init`

Scaffold a new config file.

```bash
yyoreel init
yyoreel init --name login-flow --url https://myapp.com
yyoreel init --name hero -o hero.config.json
```

| Option                | Default               | Description      |
| --------------------- | --------------------- | ---------------- |
| `--name <name>`       | `my-video`            | Video name       |
| `--url <url>`         | `https://example.com` | Starting URL     |
| `-o, --output <file>` | `<name>.json`         | Output file path |

### `yyoreel record`

Record videos.

```bash
yyoreel record
yyoreel record hero login
yyoreel record -c custom.config.json
```

When run without arguments, yyoreel reads `yyoreel.config.json` from the current directory and records all videos. Provide video names to record specific videos only.

Set `YYOREEL_CDP_ENDPOINT` to use an already-running Chrome instead of
downloading or launching one:

```bash
YYOREEL_CDP_ENDPOINT=http://127.0.0.1:9222 yyoreel record
```

The value can be an HTTP(S) endpoint, a raw WebSocket debugger URL, or a port.
yyoreel creates a dedicated page target and closes only that target after the
run, leaving the browser running. Recording and preview use the same viewport
emulation, capture pacing, Retina quality, autozoom, background, cursor, and HUD
paths as launch mode. Device emulation changes the attached page and recording
dimensions, not the existing browser window size.

### `yyoreel preview`

Run a video in a visible browser window without recording.

```bash
yyoreel preview
yyoreel preview hero
```

### `yyoreel install`

Download Chrome and ffmpeg to `~/.yyoreel`. Both are also auto-downloaded on first run. Use `--force` to fix corrupted or broken binaries.

```bash
yyoreel install
yyoreel install --force
```

### `yyoreel validate`

Check config files for errors without running them.

```bash
yyoreel validate
yyoreel validate -c custom.config.json
```

### `yyoreel composite`

Re-composite videos from stored raw recordings and timelines without re-recording.

```bash
yyoreel composite
yyoreel composite hero login
```

Raw video and timeline data are saved in `.yyoreel/raw/` and `.yyoreel/timelines/` during `yyoreel record`. Use `composite` to re-apply the recording background, cursor overlays, HUD, and sound effects without re-running the browser.

## Config format

```json
{
  "$schema": "https://yyoreel.dev/schema/v1.json",
  "videos": {
    "my-video": {
      "url": "https://example.com",
      "defaultDelay": 500,
      "steps": [
        { "action": "pause", "ms": 500 },
        { "action": "click", "text": "Get Started" },
        { "action": "key", "key": "cmd+a", "delay": 1000 }
      ]
    }
  }
}
```

When `viewport` is omitted on macOS, yyoreel uses the main display's usable area in logical CSS pixels. On unsupported platforms or when display discovery is unavailable, it falls back to a 1080x1080 CSS viewport. Set an explicit `{ "width": ..., "height": ... }` value or a named preset to override automatic sizing.

### Config options

| Field          | Default       | Description                                                            |
| -------------- | ------------- | ---------------------------------------------------------------------- |
| `url`          | required      | URL to navigate to                                                     |
| `baseUrl`      | `""`          | Prepended to relative URLs                                             |
| `viewport`     | main display  | Usable logical area on macOS, with a 1080x1080 fallback                |
| `zoom`         | -             | CSS zoom level applied to the page                                     |
| `autoZoom`     | `true`        | Spring-zoom the recording card around related clicks                   |
| `fps`          | `60`          | Recording frame rate                                                   |
| `quality`      | `80`          | Final quality and 1x or 2x physical pixel density                      |
| `waitFor`      | -             | CSS selector to wait for before starting                               |
| `output`       | `<name>.mp4`  | Output file path (`.mp4`, `.gif`, or `.webm`)                          |
| `thumbnail`    | `{ time: 0 }` | Object with `time` (seconds) or `enabled: false`                       |
| `theme`        | -             | Recording background and overlay theme (`background`, `cursor`, `hud`) |
| `include`      | -             | Array of JSON file paths whose steps are prepended                     |
| `defaultDelay` | -             | Default delay (ms) after each step                                     |

### Actions

| Action       | Fields                                                 | Description                           |
| ------------ | ------------------------------------------------------ | ------------------------------------- |
| `pause`      | `ms`                                                   | Wait for a duration                   |
| `click`      | `text` or `selector`, optional `within`, `modifiers`   | Move cursor to an element and click   |
| `key`        | `key` (e.g. `"cmd+z"`), optional `label`, `target`     | Press a key or key combo              |
| `type`       | `text`, optional `target`, `charDelay`                 | Type text character by character      |
| `drag`       | `from` and `to` (each with `text`/`selector`/`within`) | Drag from one element to another      |
| `scroll`     | optional `x`, `y`, `selector`                          | Scroll the page or a container        |
| `wheel`      | `deltaY`, optional `deltaX`, `count`, element target   | Dispatch real mouse wheel events      |
| `wait`       | `selector` or `text`, optional `timeout`               | Wait for an element or text to appear |
| `moveTo`     | `text` or `selector`, optional `within`                | Move cursor to an element             |
| `screenshot` | `output`                                               | Save a PNG screenshot                 |
| `navigate`   | `url`                                                  | Navigate to a new URL mid-video       |
| `hover`      | `text` or `selector`, optional `within`                | Hover over an element (triggers CSS)  |
| `select`     | `selector`, `value`                                    | Select a value in a dropdown          |

All steps (except `pause`) accept an optional `delay` field (ms to wait after the step). Use `defaultDelay` at the top-level or per-video to set a default.

`quality` controls both physical capture density and final compression. Values from 80 through 100 preserve the resolved CSS viewport while doubling the output width and height. Values from 1 through 79 retain 1x output dimensions. If a 1x viewport has an odd dimension, yyoreel keeps its CSS layout and pads that output edge by one pixel for compatible 4:2:0 video. On a 2x Retina Mac, the default quality of 80 therefore matches native display density, but capture density still comes from `quality`, not the display's device pixel ratio. Chrome supplies lossless PNG screencast frames. During capture, yyoreel remuxes those frames so video encoding cannot slow the output clock. Once capture stops, it compacts the retained raw with lossless ultrafast QP0 H.264 RGB while preserving the source RGB samples. A fixed output clock reuses the latest source frame when necessary to maintain the requested frame rate. For MP4 output, the final H.264 encode is the only lossy generation, using the quality-to-CRF mapping, the `veryfast` preset, and compatible 4:2:0 output. WebM and GIF exports apply their format-specific delivery encode after composition.

Cursor `animationStyle` accepts only `"smooth"`, `"medium"`, `"rapid"`, or `"none"`. The default is `"medium"`, which preserves yyoreel's existing humanized cursor motion. The `"none"` preset teleports pointer moves while retaining the intermediate events required for drag actions.

Cap-style autozoom is enabled by default for recordings. Related clicks merge into one continuous spring-driven segment, edge focus stays in bounds, and meaningful cursor movement re-aims the view. With a recording background, the complete rounded card and shadow scale and pan over the fixed canvas, so padding shrinks naturally instead of remaining constant. The cursor scales with the card and the keystroke HUD stays screen-fixed. Static `zoom` still applies first during capture. Set `autoZoom` to `false` to disable it.

Set `theme.background` to `"none"` (the default), a hex color such as `"#8b5cf6"`, or a local image path such as `"./assets/background.png"`. A color or image presents the captured recording as a centered, rounded card with a subtle shadow while preserving the configured output dimensions. Autozoom transforms the card over the fixed background. Image paths resolve relative to the config file and use center-cropped cover scaling. The keystroke HUD remains at canvas level above the card.

Set `theme.hud.enabled` to `false` to hide the keystroke and shortcut HUD in previews and recorded output. It defaults to `true`. Disabled recordings omit HUD state from the timeline, so MP4, WebM, GIF, autozoom, and background-inset output all remain HUD-free.

The contrast-safe built-in arrow remains the cursor through movement, hover, and click press. A custom cursor image likewise remains unchanged while clicking. Click press and release use a 100ms cubic ease-out scale transition, reaching `0.75` at full press without swapping cursor artwork.

## License

Apache-2.0
